const config = {
  API_URL: "http://18.192.51.153:4002/api/v1/dashboard",
};

export default config;
